// realUrl = 重定向('https://play.fuqizhishi.com/juhe/API.php?appkey=caijijuhe220902&url='+vipUrl)
// https://play.fuqizhishi.com/jx2/API.php?appkey=iiiixiaobai&url=
// realUrl = 重定向('http://jxhc.ioivip.xyz/?url='+vipUrl);
realUrl = 重定向('https://play.fuqizhishi.com/jx2/API.php?appkey=iiiixiaobai&url='+vipUrl)