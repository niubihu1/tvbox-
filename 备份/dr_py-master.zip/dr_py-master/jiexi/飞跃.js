// realUrl = 重定向('http://ivips.ml/jx/json.php/?url='+vipUrl)
realUrl = 重定向('http://103.40.240.46/jh/?url='+vipUrl)