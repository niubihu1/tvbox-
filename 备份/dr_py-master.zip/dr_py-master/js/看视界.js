var rule = Object.assign(muban.mxone5,{
title:'看视界',
host:'https://www.1080kan.cc',
headers:{'User-Agent':'MOBILE_UA'},
});