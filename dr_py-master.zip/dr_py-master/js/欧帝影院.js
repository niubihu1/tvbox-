muban.mxpro.二级.desc = ';;;.module-info-item:eq(2) .module-info-item-content&&Text;.module-info-item:eq(1) .module-info-item-content&&Text';
muban.mxpro.二级.tabs = '#y-playList .module-tab-item';
var rule={
    title:'欧帝影院',
    模板:'mxpro',
    host:'https://www.odivod.com',
    cate_exclude:'午夜专场',
}